import React from 'react';
import Tag from './Tag'
import Card from './Card'
import Markdown from './Markdown'
import Row from './Row'
const Col = (props) => {
  
    let colfinal = props.coldata.map((data,index)=>{
       
    return (<div className={data.props.className} key={index}>{data.props.children.map((subdata,index)=>{
     if(subdata.component === "Card"){
         return <Card carddata={subdata} key={index}/>
     }else if(subdata.component === "Tag"){
         return <Tag tagdata={subdata} key={index}/>
     }else if(subdata.component === "Markdown"){
         return <Markdown markdata={subdata} key={index}/>
     }else if(subdata.component === "Row"){
         return <Row props={subdata} key={index}/>
     }
    })}</div>)
    })
    return (
        <React.Fragment>
            {colfinal}
        </React.Fragment>
    );
};

export default Col;