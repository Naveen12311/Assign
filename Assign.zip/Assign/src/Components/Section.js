import React from 'react';
import Col from './Col';

const Section = (props)=>{

    return(
        <React.Fragment>
    <h2>{props.props.props.h2}</h2>
    <p>{props.props.props.text}</p>
     <Col coldata={props.props.props.children}>{props.children}</Col>
        </React.Fragment>
    )
}
export default Section;