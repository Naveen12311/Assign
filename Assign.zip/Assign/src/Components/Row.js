import React from 'react';
import Col from './Col'
const Row = (props)=>{
    console.log()
    return(
        <React.Fragment>
          <Col coldata={props.props.props.children} />
        </React.Fragment>
    )
}
export default Row;