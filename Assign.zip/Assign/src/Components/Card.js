import React from 'react';


const Card = (props) =>{

    return(<React.Fragment>
<div id="blog">{props.carddata.props.title}</div>
    <a href={props.carddata.props.link}>{props.carddata.props.text}</a>
    </React.Fragment>)
}
export default Card;