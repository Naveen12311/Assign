import React from 'react';

const Tag = (props) =>{

    return(<React.Fragment>
<div className={props.tagdata.props.className}>{props.tagdata.props.children}</div>
    </React.Fragment>)
}
export default Tag;