import React from 'react';
import ReactMarkDown from 'react-markdown';

const Markdown = (props) =>{
 
   let text = props.markdata.props.text
    return(<React.Fragment>
<ReactMarkDown source={text} />
    </React.Fragment>)
}
export default Markdown;