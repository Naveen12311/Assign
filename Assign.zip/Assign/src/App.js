import React,{Component} from 'react';
import './App.css';
import Section from './Components/Section';
import Row from './Components/Row';
import {data} from './data';
import ErrorBoundary from './Components/ErrorHandling'

class App extends Component {
 render(){
            let output = data.map((comp,index)=>{
              if(comp.component === "Section"){
              return <Section props={comp} key={index}>{this.props.children}</Section>
              }else if(comp.component === "Row"){
              return <Row props={comp} key={index}>{this.props.children}</Row>
              
            }
 
})
return(
<ErrorBoundary>
<React.Fragment> 
  {output}
  </React.Fragment>
  </ErrorBoundary>
  )
}
}
export default App;
